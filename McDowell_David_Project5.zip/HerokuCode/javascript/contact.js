function displayThankYou() {
    if(window.confirm("Click OK to submit..."))
    {
        alert("Thank you…. a confirmation email message will be sent to you soon. This is a test");
    }
}